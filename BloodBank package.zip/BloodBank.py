import mysql.connector as sqltor
mydb = sqltor.connect(host = "localhost",user = "root",passwd = "Anshika@123",database = "blood_bank")
cursor = mydb.cursor()
def Admin():
    user = str(input("Enter your Username : "))
    password = str(input("Enter your Password : "))
    if user=="Indravati"and password=="Airoli03":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE INDRAVATI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM INDRAVATI"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
                 
    elif user=="Avdhoot"and password=="Airoli19":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE AVDHOOT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM AVDHOOT"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
       
    elif user=="Apple"and password=="Airoli08":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APPLE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APPLE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APPLE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APPLE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APPLE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APPLE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APPLE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APPLE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APPLE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APPLE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APPLE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APPLE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APPLE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APPLE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APPLE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APPLE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM APPLE"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
        
    elif user=="Rajpal"and password=="Koparkhairane12":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RAJPAL SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RAJPAL SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RAJPAL SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RAJPAL SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RAJPAL SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RAJPAL SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RAJPAL SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RAJPAL SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RAJPAL SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RAJPAL SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RAJPAL SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RAJPAL SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RAJPAL SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RAJPAL SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RAJPAL SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RAJPAL SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM RAJPAL"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
    elif user=="Reliance"and password=="KoparkhairaneTBR":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RELIANCE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RELIANCE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RELIANCE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RELIANCE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RELIANCE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RELIANCE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RELIANCE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE RELIANCE SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RELIANCE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RELIANCE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RELIANCE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RELIANCE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RELIANCE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RELIANCE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RELIANCE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE RELIANCE SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM RELIANCE"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
    elif user=="SaiSnehdeep"and password=="Koparkhairane20":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no ,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAISNEHDEEP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM SAISNEHDEEP"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
    elif user=="Saarthi"and password=="BhandupW":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAARTHI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAARTHI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAARTHI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAARTHI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAARTHI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAARTHI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAARTHI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SAARTHI SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAARTHI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAARTHI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAARTHI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAARTHI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAARTHI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAARTHI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAARTHI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SAARTHI SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM SAARTHI"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")

    elif user=="Bhatia"and password=="BhandupWest":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BHATIA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BHATIA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BHATIA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BHATIA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BHATIA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BHATIA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BHATIA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BHATIA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BHATIA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BHATIA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BHATIA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BHATIA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BHATIA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BHATIA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BHATIA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BHATIA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM BHATIA"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
    elif user=="Mrudula"and password=="BhandupE":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE MRUDULA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE MRUDULA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE MRUDULA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE MRUDULA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE MRUDULA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE MRUDULA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE MRUDULA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE MRUDULA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE MRUDULA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE MRUDULA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE MRUDULA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE MRUDULA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE MRUDULA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE MRUDULA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE MRUDULA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE MRUDULA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM MRUDULA"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
                
    elif user=="NewJP"and password=="Sakinaka":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE NEWJP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE NEWJP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE NEWJP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE NEWJP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE NEWJP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE NEWJP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE NEWJP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE NEWJP SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE NEWJP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE NEWJP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE NEWJP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE NEWJP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE NEWJP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE NEWJP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE NEWJP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE NEWJP SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM NEWJP"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
                
    elif user=="Sevenhills"and password=="SakinakaM":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE SEVENHILLS SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM SEVENHILLS"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
                
    elif user=="Paramount"and password=="SakinakaAE":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE PARAMOUNT SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM PARAMOUNT"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
                
    elif user=="Barc"and password=="MankhurdAN":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BARC SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BARC SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BARC SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BARC SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BARC SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BARC SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BARC SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE BARC SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BARC SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BARC SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BARC SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BARC SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BARC SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BARC SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BARC SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE BARC SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM BARC"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
    
    
        
    elif user=="Vishwakarma"and password=="MankhurdS":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE VISHWAKARMA SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM VISHWAKARMA"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
                
    elif user=="Apex"and password=="MankhurdW":
        print()
        print("Successfully logged in! ")
        a=1
        while a<5:
            print()
            print("1.INSERT")
            print("2.UPDATE")
            print("3.DISPLAY")
            print("4.DELETE")
            print("5.EXIT")
            print()
            a=int(input("Enter your choice: "))
            print()
            if a==1:
                b=1
                while b<3:
                    print()
                    print("1.ADD DONOR DETAILS")
                    print("2.REGISTER A DONOR")
                    print("3.EXIT")
                    print()
                    b=int(input("Enter your choice: "))
                    print()
                    if b==1:
                        sql= """INSERT INTO DONOR(NAME,AGE,GENDER,DOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID,HOSPITAL_NAME)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        dod=str(input("Enter the date in format YYYY-MM-DD : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        hospital_name=str(input("Enter Hospital's Name: "))
                        val=(name,age,gender,dod,blood_group,phone_no,address,email_id,hospital_name)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==2:
                        sql= """INSERT INTO REGISTERED_DONOR(NAME,AGE,GENDER,NOD,BLOOD_GROUP,PHONE_NO,ADDRESS,EMAIL_ID)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"""
                        name=str(input("Enter name of the donor: "))
                        age=int(input("Enter the age of the donor: "))
                        gender=str(input("Enter M for Male , F for Female , O for others : "))
                        nod=int(input("Enter number of donation : "))
                        blood_group=str(input("Enter blood group of the donor: "))
                        phone_no=str(input("Enter the phone no of the donor: "))
                        address=str(input("Enter the address of the donor: "))
                        email_id=str(input("Enter the email id of the donor: "))
                        val=(name,age,gender,nod,blood_group,phone_no,address,email_id)
                        cursor.execute(sql,val)
                        mydb.commit()
                        print()
                        print("DATA INSERTED SUCCESFULLY !")
                    elif b==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==2:
                c=1
                while c<3:
                    print("1.Update Number of Donors")
                    print("2.Update Number of Units")
                    print("3.EXIT")
                    c=int(input("Enter your choice"))
                    if c==1:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APEX SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APEX SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APEX SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APEX SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APEX SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APEX SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APEX SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of donors: "))
                                sql= """UPDATE APEX SET NO_OF_DONOR = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==2:
                        bg=1
                        while bg<9:
                            print()
                            print("1. O+")
                            print("2. A+")
                            print("3. B+")
                            print("4. AB+")
                            print("5. O-")
                            print("6. A-")
                            print("7. B-")
                            print("8. AB-")
                            print("9. EXIT")
                            print()
                            bg=int(input("Enter your choice : "))
                            print()
                            if bg==1:
                                b="O+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APEX SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==2:
                                b="A+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APEX SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==3:
                                b="B+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APEX SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==4:
                                b="AB+"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APEX SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==5:
                                b="O-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APEX SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==6:
                                b="A-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APEX SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==7:
                                b="B-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APEX SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==8:
                                b="AB-"
                                n=int(input("Enter no of units: "))
                                sql= """UPDATE APEX SET NO_OF_UNITS = %s WHERE BLOOD_GROUP = %s"""
                                val=(n,b)
                                cursor.execute(sql,val)
                                mydb.commit()
                                print()
                                print("DATA UPDATED SUCCESFULLY")
                            elif bg==9:
                                break
                            else:
                                print("Invalid Choice")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==3:
                c=1
                while c<4:
                    print()
                    print("1 Display Blood Details")
                    print("2 Display Donor Details")
                    print("3 Display Registered Donor Details")
                    print("4 Exit")
                    print()
                    c=int(input("Enter your choice : "))
                    if c==1:
                        sql="""SELECT * FROM APEX"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==2:
                        sql="""SELECT * FROM DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==3:
                        sql="""SELECT * FROM REGISTERED_DONOR"""
                        cursor.execute(sql)
                        data=cursor.fetchall()
                        for row in data:
                            print(row)
                    elif c==4:
                        break
                    else:
                        print("Invalid Choice")
            elif a==4:
                c=1
                while c<3:
                    print()
                    print("1 DELETE FROM DONOR DETAILS")
                    print("2 DELETE FROM REGISTERED DONOR DETAILS")
                    print("3 EXIT")
                    print()
                    c=int(input("Enter your choice : "))
                    print()
                    if c==1:
                        sql="""DELETE FROM DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==2:
                        sql="""DELETE FROM REGISTERED_DONOR WHERE EMAIL_ID =%s"""
                        email=str(input("Enter the email id of the donor whose details are to be deleted : "))
                        email_id=(email, )
                        cursor.execute(sql,email_id)
                        mydb.commit()
                        print()
                        print("DATA DELETED SUCCESFULLY")
                    elif c==3:
                        break
                    else:
                        print("Invalid Choice")
            elif a==5:
                break
            else:
                print("Invalid Choice")
           
    else:
        print("Invalid username or password")



def Donor():
    print()
    print("1 NAVI MUMBAI")
    print("2 MUMBAI")
    print("3 EXIT")
    print()
    ch=int(input("Enter your locality : "))
    print()
    if ch==1:
        print()
        print("1 AIROLI")
        print("2 KOPARKHAIRNE")
        print("3 MANKHURD")
        print("4 EXIT")
        print()
        city=int(input("Enter your nearest city : "))
        print()
        if city==1:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1>=data2 and data1>=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2>=data1 and data2>=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            else:
                print("Invalid Choice")
        elif city==2:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            else:
                print("Invalid Choice")
        elif city==3:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
        else:
            print("Invalid Choice")
    elif ch==2:
        print()
        print("1 BHANDUP")
        print("2 SAKINAKA")
        print("3 EXIT")
        print()
        city=int(input("Enter your nearest city"))
        print()
        if city==1:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
        elif city==2:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
        else:
            print("Invalid Choice")
    else:
        print("Invalid Choice")

        
def RDonor():
    print()
    print("1 NAVI MUMBAI")
    print("2 MUMBAI")
    print("3 EXIT")
    print()
    ch=int(input("Enter your locality : "))
    print()
    if ch==1:
        print()
        print("1 AIROLI")
        print("2 KOPARKHAIRNE")
        print("3 MANKHURD")
        print("4 EXIT")
        print()
        city=int(input("Enter your nearest city : "))
        print()
        if city==1:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1>=data2 and data1>=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2>=data1 and data2>=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            else:
                print("Invalid Choice")
        elif city==2:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            else:
                print("Invalid Choice")
        elif city==3:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
        else:
            print("Invalid Choice")
    elif ch==2:
        print()
        print("1 BHANDUP")
        print("2 SAKINAKA")
        print("3 EXIT")
        print()
        city=int(input("Enter your nearest city : "))
        print()
        if city==1:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
        elif city==2:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data2<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
        else:
            print("Invalid Choice")
    else:
        print("Invalid Choice")

                
def Seeker():
    print()
    print("1 NAVI MUMBAI")
    print("2 MUMBAI")
    print("3 EXIT")
    print()
    ch=int(input("Enter your locality : "))
    print()
    if ch==1:
        print()
        print("1 AIROLI")
        print("2 KOPARKHAIRNE")
        print("3 MANKHURD")
        print("4 EXIT")
        print()
        city=int(input("Enter your nearest city : "))
        print()
        if city==1:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1>=data2 and data1>=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2>=data1 and data2>=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            else:
                print("Invalid Choice")
        elif city==2:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            else:
                print("Invalid Choice")
        elif city==3:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
        else:
            print("Invalid Choice")
    elif ch==2:
        print()
        print("1 BHANDUP")
        print("2 SAKINAKA")
        print("3 EXIT")
        print()
        city=int(input("Enter your nearest city"))
        print()
        if city==1:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
        elif city==2:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==2:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==3:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==4:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==5:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==6:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==7:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==8:
                sql="""SELECT NO_OF_UNITS FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_UNITS FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
        else:
            print("Invalid Choice")
    else:
        print("Invalid Choice")

def RSeeker():
    print()
    print("1 NAVI MUMBAI")
    print("2 MUMBAI")
    print("3 EXIT")
    print()
    ch=int(input("Enter your locality : "))
    print()
    if ch==1:
        print()
        print("1 AIROLI")
        print("2 KOPARKHAIRNE")
        print("3 MANKHURD")
        print("4 EXIT")
        print()
        city=int(input("Enter your nearest city : "))
        print()
        if city==1:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1>=data2 and data1>=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2>=data1 and data2>=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM INDRAVATI WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM AVDHOOT WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM APPLE WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT INDRAVATI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2568956214")
                elif data2<=data1 and data2<=data3:
                    print("VISIT AVDHOOT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5625896452")
                else:
                    print("VISIT APPLE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569863521")
            else:
                print("Invalid Choice")
        elif city==2:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM RAJPAL WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM RELIANCE WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SAISNEHDEEP WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT RAJPAL HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269865325")
                elif data2<=data1 and data2<=data3:
                    print("VISIT RELIANCE HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 2569834587")
                else:
                    print("VISIT SAISNEHDEEP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685325648")
            else:
                print("Invalid Choice")
        elif city==3:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM APEX WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BARC WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM VISHWAKARMA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT APEX HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5869452365")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BARC HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 6589745896")
                else:
                    print("VISIT VISHWAKARMA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9865745256")
        else:
            print("Invalid Choice")
    elif ch==2:
        print()
        print("1 BHANDUP")
        print("2 SAKINAKA")
        print("3 EXIT")
        print()
        city=int(input("Enter your nearest city"))
        print()
        if city==1:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM SAARTHI WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM BHATIA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM MRUDULA WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT SAARTHI HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 8965425698")
                elif data2<=data1 and data2<=data3:
                    print("VISIT BHATIA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5269874569")
                else:
                    print("VISIT MRUDULA HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685326589")
        elif city==2:
            print()
            print("1. O+")
            print("2. A+")
            print("3. B+")
            print("4. AB+")
            print("5. O-")
            print("6. A-")
            print("7. B-")
            print("8. AB-")
            print("9. EXIT")
            print()
            bg=int(input("Enter your choice : "))
            print()
            if bg==1:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("O+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==2:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("A+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==3:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("B+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==4:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("AB+", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==5:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("O-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==6:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("A-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==7:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("B-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
            elif bg==8:
                sql="""SELECT NO_OF_DONOR FROM PARAMOUNT WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data1=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM NEWJP WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data2=cursor.fetchone()
                sql="""SELECT NO_OF_DONOR FROM SEVENHILLS WHERE BLOOD_GROUP=%s"""
                val=("AB-", )
                cursor.execute(sql,val)
                data3=cursor.fetchone()
                if data1<=data2 and data1<=data3:
                    print("VISIT PARAMOUNT HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 5698236548")
                elif data2<=data1 and data<=data3:
                    print("VISIT NEWJP HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9856325478")
                else:
                    print("VISIT SEVENHILLS HOSPITAL FOR FURTHER PROCEDURE")
                    print("PHONE NO : 9685412365")
        else:
            print("Invalid Choice")
    else:
        print("Invalid Choice")
#MAIN MENU
        
choice=0
while choice<4:
    print("**********************WELCOME************************")
    print()
    print("1. ADMIN ")
    print("2. DONOR ")
    print("3. SEEKER ")
    print("4. EXIT ")
    print()
    choice = int(input("Enter your choice : "))
    print()
    if choice==1:
        Admin()
    elif choice==2:
        ch=1
        while ch<3:
            print()
            print("1 DONATE BLOOD")
            print("2 REGISTER AS DONOR")
            print("3 EXIT")
            print()
            ch=int(input("Enter your choice : "))
            if ch==1:
                Donor()
            elif ch==2:
                RDonor()
            else:
                print("Invalid Choice")
    elif choice==3:
        ch=1
        while ch<3:
            print()
            print("1 SEARCH A DONOR")
            print("2 SEARCH HOSPITAL")
            print("3 EXIT")
            print()
            ch=int(input("Enter your choice : "))
            if ch==1:
                RSeeker()
            elif ch==2:
                Seeker()
            else:
                print("Invalid Choice")
    else:
        print("THANKYOU!")
